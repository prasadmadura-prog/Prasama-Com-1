
import React, { useState } from 'react';
import { View, UserProfile, BankAccount } from '../types';

interface SidebarProps {
  currentView: View;
  setView: (v: View) => void;
  userProfile: UserProfile;
  accounts: BankAccount[];
  onEditProfile: () => void;
  onLogout: () => void;
  onSwitchBranch?: (branch: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, userProfile, accounts, onEditProfile, onLogout, onSwitchBranch }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const menuItems = [
    { id: 'DASHBOARD', label: 'Dashboard', icon: '📊' },
    { id: 'AI_ADVISOR', label: 'AI Advisor', icon: '✨' },
    { id: 'POS', label: 'POS', icon: '🛒' },
    { id: 'QUOTATIONS', label: 'Quotation', icon: '📝' },
    { id: 'SALES_HISTORY', label: 'Sales History', icon: '📜' },
    { id: 'INVENTORY', label: 'Inventory', icon: '📦' },
    { id: 'BARCODE_PRINT', label: 'Barcode Print', icon: '🏷️' },
    { id: 'PURCHASES', label: 'Purchases', icon: '📥' },
    { id: 'CUSTOMERS', label: 'Customers', icon: '👥' },
    { id: 'FINANCE', label: 'Finance', icon: '💰' },
    { id: 'CHEQUE_PRINT', label: 'Cheque Print', icon: '✍️' },
    { id: 'SETTINGS', label: 'Settings', icon: '⚙️' },
  ];

  const initials = userProfile.name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  const branches = userProfile.allBranches || ["Bookshop", "Shop 2"];

  return (
    <div className={`${isCollapsed ? 'w-[80px]' : 'w-[260px]'} h-full bg-[#0f172a] text-slate-300 flex flex-col border-r border-slate-800/50 shadow-2xl z-20 transition-all duration-300 ease-in-out relative`}>
      {/* Collapse Toggle for Tablet */}
      <button 
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="absolute -right-3 top-10 w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center text-white shadow-lg z-50 hover:bg-indigo-500 border border-indigo-400"
      >
        {isCollapsed ? '→' : '←'}
      </button>

      {/* Condensed Header */}
      <div className={`px-4 pt-6 pb-4 ${isCollapsed ? 'items-center' : ''} flex flex-col`}>
        <div className="flex items-center gap-3 mb-4 w-full">
          <div className="w-10 h-10 min-w-[40px] rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-lg">
            <span className="font-black text-xl italic">P</span>
          </div>
          {!isCollapsed && (
            <div className="overflow-hidden">
              <h1 className="text-xs font-black tracking-tight text-white leading-tight truncate uppercase">{userProfile.name}</h1>
              <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest opacity-80">Strategic Suite</p>
            </div>
          )}
        </div>

        {/* Branch Switcher */}
        {!isCollapsed && (
          <div className="mb-4 w-full">
            <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1.5 block">Active Shop Node</label>
            <select 
              value={userProfile.branch} 
              onChange={(e) => onSwitchBranch?.(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-[11px] font-black text-indigo-400 outline-none focus:border-indigo-500 uppercase cursor-pointer"
            >
              {branches.map(b => <option key={b} value={b}>{b}</option>)}
            </select>
          </div>
        )}

        {/* Compact Liquidity Box */}
        {!isCollapsed && (
          <div className="bg-slate-900/50 border border-slate-800/50 rounded-2xl p-3 mb-2 w-full">
             <div className="flex justify-between items-center mb-2">
                <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Live Liquidity</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
             </div>
             <div className="grid grid-cols-2 gap-2">
                {accounts.slice(0, 4).map(acc => (
                  <div key={acc.id} className="min-w-0">
                     <p className="text-[9px] font-black text-slate-500 uppercase truncate mb-0.5">{acc.name}</p>
                     <p className="text-[10px] font-black text-white font-mono truncate">
                        {Number(acc.balance).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                     </p>
                  </div>
                ))}
             </div>
          </div>
        )}
      </div>

      {/* High-Density Navigation */}
      <nav className="flex-1 px-3 space-y-1 overflow-y-auto custom-scrollbar pt-2">
        {menuItems.map((item) => {
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setView(item.id as View)}
              title={item.label}
              className={`w-full group flex items-center ${isCollapsed ? 'justify-center px-0' : 'px-4'} py-3 text-[11px] font-black uppercase tracking-widest rounded-xl transition-all duration-200 ${
                isActive 
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' 
                  : 'text-slate-500 hover:bg-slate-800/40 hover:text-slate-200'
              }`}
            >
              <span className={`text-xl transition-transform group-hover:scale-110 ${isCollapsed ? 'mr-0' : 'mr-3'} ${isActive ? 'opacity-100' : 'opacity-30'}`}>
                {item.icon}
              </span>
              {!isCollapsed && <span>{item.label}</span>}
            </button>
          );
        })}
      </nav>

      {/* Footer Profile */}
      <div className="p-3 mt-auto border-t border-slate-800/30 space-y-1.5">
        <button 
          onClick={onEditProfile}
          className={`w-full flex items-center ${isCollapsed ? 'justify-center' : 'gap-2.5'} bg-slate-900/30 p-2.5 rounded-xl border border-slate-800/30 hover:bg-slate-800/60 transition-all text-left group`}
        >
          <div className="w-9 h-9 min-w-[36px] rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-[11px] font-black text-indigo-400">
            {initials}
          </div>
          {!isCollapsed && (
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-bold text-white truncate uppercase tracking-tighter">{userProfile.name}</p>
              <p className="text-[9px] text-slate-500 font-bold uppercase tracking-tight truncate">{userProfile.branch}</p>
            </div>
          )}
        </button>

        <button 
          onClick={onLogout}
          className={`w-full flex items-center ${isCollapsed ? 'justify-center' : 'gap-2 px-4'} py-2.5 text-[9px] font-black uppercase tracking-[0.2em] text-slate-600 hover:text-rose-400 transition-all duration-200`}
        >
          <span>🚪</span> {!isCollapsed && 'Exit Terminal'}
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
