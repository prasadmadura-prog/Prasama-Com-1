
import React, { useState, useMemo, useEffect } from 'react';
import { Transaction, Product, Customer, UserProfile, BankAccount } from '../types';

interface SalesHistoryProps {
  transactions: Transaction[];
  products: Product[];
  customers: Customer[];
  userProfile: UserProfile;
  accounts: BankAccount[];
  onUpdateTransaction: (tx: Transaction) => void;
  onDeleteTransaction: (id: string) => void;
}

const SalesHistory: React.FC<SalesHistoryProps> = ({ 
  transactions = [], 
  products = [], 
  customers = [], 
  userProfile, 
  accounts = [],
  onUpdateTransaction,
  onDeleteTransaction
}) => {
  const getTodayLocal = () => {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  };

  const today = getTodayLocal();
  const [searchTerm, setSearchTerm] = useState('');
  const [startDate, setStartDate] = useState(today);
  const [endDate, setEndDate] = useState(today);
  const [activeTab, setActiveTab] = useState<'ALL' | 'PAID' | 'DUE'>('ALL');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [tempItems, setTempItems] = useState<{ productId: string; quantity: number; price: number; discount?: number }[]>([]);
  const [tempTotal, setTempTotal] = useState(0);
  const [showItemPicker, setShowItemPicker] = useState(false);
  const [itemSearch, setItemSearch] = useState('');

  useEffect(() => {
    if (editingTx) {
      setTempItems(editingTx.items || []);
      setTempTotal(editingTx.amount);
    }
  }, [editingTx]);

  useEffect(() => { setEndDate(getTodayLocal()); }, []);

  const ledgerEntries = useMemo(() => {
    if (!Array.isArray(transactions)) return [];
    return transactions.filter(t => t && (t.type === 'SALE' || t.type === 'CREDIT_PAYMENT'));
  }, [transactions]);

  const filteredEntries = useMemo(() => {
    return ledgerEntries
      .filter(s => {
        const txId = (s.id || "").toLowerCase();
        const matchesSearch = txId.includes(searchTerm.toLowerCase());
        const txDateStr = typeof s.date === 'string' ? s.date.split('T')[0] : '';
        const matchesRange = (!startDate || txDateStr >= startDate) && (!endDate || txDateStr <= endDate);
        const matchesTab = activeTab === 'ALL' || (activeTab === 'PAID' && s.paymentMethod !== 'CREDIT') || (activeTab === 'DUE' && s.paymentMethod === 'CREDIT');
        return matchesSearch && matchesRange && matchesTab;
      })
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [ledgerEntries, searchTerm, startDate, endDate, activeTab]);

  const getCustomerName = (id?: string) => customers.find(c => c.id === id)?.name || 'Walk-in Customer';

  const summaryStats = useMemo(() => {
    const rangeEntries = ledgerEntries.filter(s => {
        const txDateStr = typeof s.date === 'string' ? s.date.split('T')[0] : '';
        return (!startDate || txDateStr >= startDate) && (!endDate || txDateStr <= endDate);
    });

    const costOfRevenue = rangeEntries
      .filter(s => s.type === 'SALE')
      .reduce((acc, t) => {
        const itemsCost = t.items?.reduce((itemAcc, item) => {
          const product = products.find(p => p.id === item.productId);
          return itemAcc + (Number(product?.cost || 0) * Number(item.quantity));
        }, 0) || 0;
        return acc + itemsCost;
      }, 0);

    const salesRevenue = rangeEntries
      .filter(s => (s.type === 'SALE' && s.paymentMethod !== 'CREDIT') || s.type === 'CREDIT_PAYMENT')
      .reduce((a, b) => a + Number(b.amount || 0), 0);

    const profit = salesRevenue - costOfRevenue;
    const margin = salesRevenue > 0 ? (profit / salesRevenue) * 100 : 0;
    const yieldOnInvestment = costOfRevenue > 0 ? (profit / costOfRevenue) * 100 : 0;

    const dueAmount = rangeEntries
      .filter(s => s.type === 'SALE' && s.paymentMethod === 'CREDIT')
      .reduce((a, b) => a + Number(b.amount || 0), 0);

    return { costOfRevenue, salesRevenue, profit, margin, yieldOnInvestment, dueAmount };
  }, [ledgerEntries, startDate, endDate, products]);

  const handleExportCSV = () => {
    if (filteredEntries.length === 0) return;

    const headers = [
      'Date', 'Reference', 'Customer', 'Item Manifest', 'SKU', 'Qty', 
      'Unit Cost (Rs.)', 'Unit Price (Rs.)', 'Line Disc (Rs.)', 'Line Net (Rs.)', 
      'Line Cost (Rs.)', 'Line Profit (Rs.)', 'Yield %', 'Method'
    ];

    const rows: (string | number)[][] = [];

    filteredEntries.forEach(tx => {
      const dateStr = new Date(tx.date).toLocaleDateString();
      const customer = getCustomerName(tx.customerId).replace(/,/g, '');
      const method = tx.paymentMethod;

      if (tx.items && tx.items.length > 0) {
        tx.items.forEach(item => {
          const product = products.find(p => p.id === item.productId);
          const name = (product?.name || 'Asset').replace(/,/g, '');
          const sku = product?.sku || 'N/A';
          const cost = Number(product?.cost || 0);
          const price = Number(item.price);
          const qty = Number(item.quantity);
          const disc = Number(item.discount || 0);
          const netLine = (qty * price) - disc;
          const totalCost = qty * cost;
          const profit = netLine - totalCost;
          const itemYield = totalCost > 0 ? (profit / totalCost) * 100 : 0;

          rows.push([dateStr, tx.id, customer, name, sku, qty, cost, price, disc, netLine, totalCost, profit, itemYield.toFixed(1), method]);
        });
      } else {
        rows.push([dateStr, tx.id, customer, tx.description.replace(/,/g, ''), 'N/A', 1, 0, tx.amount, 0, tx.amount, 0, tx.amount, '100', method]);
      }
    });

    const csvContent = [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `PRASAMA_DETAILED_AUDIT_${startDate}_TO_${endDate}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleUpdate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editingTx) return;
    const fd = new FormData(e.currentTarget);
    const updated: Transaction = {
      ...editingTx,
      date: new Date(fd.get('date') as string).toISOString(),
      amount: editingTx.type === 'SALE' ? tempTotal : Number(fd.get('amount')),
      description: (fd.get('description') as string).toUpperCase(),
      paymentMethod: fd.get('paymentMethod') as any,
      accountId: fd.get('accountId') as string,
      items: editingTx.type === 'SALE' ? tempItems : undefined
    };
    onUpdateTransaction(updated);
    setIsEditModalOpen(false);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tighter">Sales History & Audit</h2>
          <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px]">Commercial cycle verification</p>
        </div>
        <div className="flex gap-4">
           <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex gap-10 overflow-x-auto">
              <div className="text-right shrink-0">
                 <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Yield</p>
                 <p className="text-xl font-black font-mono text-indigo-600">{summaryStats.yieldOnInvestment.toFixed(1)}%</p>
                 <p className="text-[10px] font-black uppercase text-slate-400">Yield on Investment</p>
              </div>
              <div className="text-right border-l border-slate-100 pl-10 shrink-0">
                 <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Profit</p>
                 <p className="text-xl font-black font-mono text-emerald-600">Rs. {summaryStats.profit.toLocaleString()}</p>
                 <p className="text-[10px] font-black uppercase text-emerald-500">Margin: {summaryStats.margin.toFixed(1)}%</p>
              </div>
              <div className="text-right border-l border-slate-100 pl-10 shrink-0">
                 <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Revenue</p>
                 <p className="text-xl font-black font-mono text-slate-600">Rs. {summaryStats.salesRevenue.toLocaleString()}</p>
              </div>
           </div>
        </div>
      </header>

      <div className="flex flex-col md:flex-row gap-4 items-center bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm">
        <div className="relative flex-1 w-full">
          <span className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400">🔍</span>
          <input type="text" placeholder="Search by Transaction ID..." className="w-full pl-14 pr-6 py-4 rounded-2xl border border-slate-200 outline-none bg-slate-50/50 font-bold text-sm" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
        </div>
        <div className="flex gap-3 w-full md:w-auto">
          <input type="date" className="px-6 py-4 rounded-2xl border border-slate-200 bg-white text-xs font-black outline-none" value={startDate} onChange={e => setStartDate(e.target.value)} />
          <input type="date" className="px-6 py-4 rounded-2xl border border-slate-200 bg-white text-xs font-black outline-none" value={endDate} onChange={e => setEndDate(e.target.value)} />
          <button onClick={handleExportCSV} className="px-6 py-4 rounded-2xl bg-indigo-600 text-white text-[10px] font-black uppercase tracking-widest shadow-lg hover:bg-indigo-700 transition-all">📥 Detailed CSV</button>
        </div>
      </div>

      <div className="bg-white rounded-[3rem] shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse">
            <thead className="bg-slate-50 text-slate-400 uppercase tracking-widest text-[9px]">
              <tr>
                <th className="px-8 py-4">Date / ID</th>
                <th className="px-8 py-4">Customer / Items sold</th>
                <th className="px-8 py-4 text-right">Value (Rs.)</th>
                <th className="px-8 py-4">Type / Method</th>
                <th className="px-8 py-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredEntries.map(tx => (
                <tr key={tx.id} className="hover:bg-slate-50 transition-all group align-top">
                  <td className="px-8 py-4">
                    <p className="font-black text-slate-900 uppercase text-[12px]">{new Date(tx.date).toLocaleDateString()}</p>
                    <p className="text-[10px] text-indigo-500 font-mono font-black uppercase mt-0.5">{tx.id}</p>
                  </td>
                  <td className="px-8 py-4">
                    <p className="font-black text-slate-700 uppercase text-[11px] mb-2">{getCustomerName(tx.customerId)}</p>
                    <div className="space-y-1 border-l-2 border-slate-100 pl-3">
                       {tx.items?.map((it, idx) => {
                         const p = products.find(prod => prod.id === it.productId);
                         return (
                           <div key={idx} className="flex items-center gap-2 text-[9px] font-black uppercase text-slate-400">
                              <span className="w-4 h-4 rounded bg-slate-100 flex items-center justify-center text-[7px] text-slate-600">{it.quantity}</span>
                              <span className="truncate max-w-[140px]">{p?.name || 'Asset'}</span>
                              <span className="ml-auto text-slate-300 font-mono text-[8px]">@ {Number(it.price).toLocaleString()}</span>
                           </div>
                         );
                       })}
                    </div>
                  </td>
                  <td className="px-8 py-4 text-right font-black text-slate-900 font-mono text-[13px]">{Number(tx.amount || 0).toLocaleString()}</td>
                  <td className="px-8 py-4">
                     <div className="flex flex-col gap-1">
                        <span className={`px-2 py-0.5 rounded-lg text-[8px] font-black uppercase tracking-widest self-start ${tx.type === 'SALE' ? 'bg-indigo-50 text-indigo-600' : 'bg-emerald-50 text-emerald-600'}`}>{tx.type}</span>
                        <span className="text-[8px] font-black uppercase text-slate-400">{tx.paymentMethod}</span>
                     </div>
                  </td>
                  <td className="px-8 py-4 text-center">
                    <div className="flex justify-center gap-2">
                      <button onClick={() => { setEditingTx(tx); setIsEditModalOpen(true); }} className="p-2.5 rounded-xl border border-slate-200 hover:bg-white shadow-sm transition-all">✏️</button>
                      <button onClick={() => onDeleteTransaction(tx.id)} className="p-2.5 rounded-xl border border-slate-200 hover:bg-rose-50 text-rose-300 hover:text-rose-600 shadow-sm transition-all">🗑️</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
export default SalesHistory;
