
// Firebase service is decommissioned. 
// System is now running on Local Persistent Ledger v9.0.
export const auth = null;
export const db = null;
export default null;
